package com.in28minutes;

public class UserValidationService {
	
	public boolean isUserValid(String user, String password) {
		if(user.equals("Amber") && password.equals("abc"))
			return true;
		return false;
	}

}
